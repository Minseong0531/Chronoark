import './App.css';
import React from 'react';
import {BrowserRouter,Route, Routes} from 'react-router-dom'
import { useState } from 'react';


function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  return (
    <div>
      <div className='min-h-screen flex flex-col'>
        <header className='bg-white shadow-md'>
          <div className="container mx-auto px-4 py-3 flex justify-between items-center">
            <h1 className='text-xl font-bold text-blue-600'>Logo</h1>
            <nav className='md:flex gap-6'>
              <a href='#' className='text-gray-700 hover:text-blue-600'>Home</a>
              <a href='#' className='text-gray-700 hover:text-blue-600'>About</a>
              <a href='#' className='text-gray-700 hover:text-blue-600'>Contact</a>
            </nav>
            <button className='md:hidden flex flex-col justify-between w-6 h-5 focus:outline-none' aria-label="toggle menu" onClick={()=>{setMenuOpen(!menuOpen)}}>
              <span className={`block h-0.5 bg-gray-700 transition-transform duration-300 ${menuOpen ? 'translate-y-2 rotate-45':''}`}></span>
              <span className={`block h-0.5 bg-gray-700 transition-transform duration-300 ${menuOpen ? 'opacity-0':''}`}></span>
              <span className={`block h-0.5 bg-gray-700 transition-transform duration-300 ${menuOpen ? '-translate-y-2 -rotate-45':''}`}></span>
            </button>
          </div>
          {menuOpen && (
            <div className='md:hidden px-4 pb-4'>
              <a href='#' className='block py-2 text-gray-700 hover:text-blue-600'>Home</a>
              <a href='#' className='block py-2 text-gray-700 hover:text-blue-600'>About</a>
              <a href='#' className='block py-2 text-gray-700 hover:text-blue-600'>Contact</a>
            </div>
          )}
        </header>
        <main className='flex-grow container mx-auto px-4 py-10'>
          <h2 className='text-2xl font-semibold mb-4'>Main Title</h2>
          <p className='text-gray-700'>
            Main Text Content's
          </p>
          <section className='py-16 bg-white'>
            <div className='container mx-auto px-4 text-center'>
              <h3 className='text-2xl font-semibold text-gray-800 mb-8'>Portfolio's</h3>
              <div className='grid md:grid-cols-3 gap-8'>
                <div className='p-6 bg-gray-50 rounded-lg shadow-sm hover:shadow-md transition'>
                  <h4 className='text-lg font-semibold text-blue-600 mb-2'>Responsive</h4>
                  <p className='text-gray-600'>Responsive Web Project</p>
                </div>
                <div className='p-6 bg-gray-50 rounded-lg shadow-sm hover:shadow-md transition'>
                  <h4 className='text-lg font-semibold text-blue-600 mb-2'>Mobile Web App</h4>
                  <p className='text-gray-600'>Responsive Application Project</p>
                </div>
                <div className='p-6 bg-gray-50 rounded-lg shadow-sm hover:shadow-md transition'>
                  <h4 className='text-lg font-semibold text-blue-600 mb-2'>UX/UI</h4>
                  <p className='text-gray-600'>Responsive UX/UI Project</p>
                </div>
              </div>
            </div>
          </section>
        </main>
        <footer className='bg-gray-100 py-4 text-center text-sm text-gray-600'>
          copyright. All rights reserved.
        </footer>
      </div>

    </div>
    
  );
}

export default App;
