import './App.css';
import {BrowserRouter,Route, Routes} from 'react-router-dom'
import React, { useState, useMemo, useEffect } from 'react';

function OptDp({options}){
  console.log('~')
  return <div className='my-6'></div>
}

const OptionDisplay = React.memo(({options})=>{
  console.log('optionDisplay Component reRendering..')

  useEffect(()=>{
    console.log('option이 바뀌면 - localStorage setItem 실행');
  },[options])

  return(
    <div className='p-4 border border-blue-300 bg-blue-50 rounded-lg'>
      <h4 className='font-bold text-blue-800 b-2'>OptionDisplay</h4>
      <p className='text-sm'>Options:{JSON.stringify(options)}</p>
    </div>
  )
});



function App() {
  const [serverUrl, setServerUrl] = useState('http://localhost:1234');
  const [roomId, setRoomId]=useState('first');
  const [message, setMessage] = useState('');
  const options = useMemo(()=>{
    console.log('새로운 option 객체 생성.')
    return{
      serverUrl:serverUrl,
      roomId:roomId,

    }
  },[serverUrl, roomId])
  return (
    <div className='app max-x-2xl mx-auto p-6 bg-white'>
      <h2 className='text-2xl font-bold mb-6 text-center'>useMemo Example</h2>
      <div className='my-6'>
        <div className='bg-green-50 p-4 rounded-lg border border-green-200'>
          <h3 className='font-semibold text-green-800 mb-3'>설정편경</h3>
          <div className='space-y-2'>
            <div>
              <label className='block text-sm font-medium mb-1'>Server URL:</label>
              <input type='text' value={serverUrl} onChange={(e)=> setServerUrl(e.target.value)} className='w-full p2 border border-gray-300 rounded'></input>
            </div>
            <div>
              <label className='block text-sm font-medium mb-1'>Room UD:</label>
              <input type='text' value={roomId} onChange={(e)=> setRoomId(e.target.value)} className='w-full p2 border border-gray-300 rounded'></input>
            </div>
          </div>
        </div>
        <div className='bg-yellow-50 p-4 rounded-lg border border-yellow-200'>
          <h3 className='font-semibold text-yellow-800 mb-3'>메세지 입력</h3>
          <div>
            <label className='block text-sm font-medium mb-1'>message</label>
            <input type='text' value={message} onChange={(e)=> setMessage(e.target.value)} className='w-full p-2 border border-gray-300 rounded' placeholder='입력공간'>

            </input>
          </div>
        </div>
      </div>
      <OptionDisplay options={options} />
    </div>
    
  );
}

export default App;
