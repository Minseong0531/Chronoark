import './App.css';
import React from 'react';
import {BrowserRouter,Route, Routes} from 'react-router-dom'

function FlexRow(){
  return(
    <div className='flex gap-4 p-4 bg-gray-100 mb-10'>
      <div className='w-24 h-20 bg-red-400'> 96 x 80</div>
      <div className='w-24 h-20 bg-green-400'> 96 x 80</div>
      <div className='w-24 h-20 bg-blue-400'> 96 x 80</div>
    </div>
  )
}
function FlexCenter(){
  return(
    <div className='flex justify-center items-center h-screen bg-slate-300'>
      <div className='p-8 bg-white rounded-lg'>
        <h2 className='text-xl font-bold mb-4'>Title</h2>
        <p className='text-gray-700'>center middle box</p>
      </div>
    </div>
  )
}
function BoxSizing(){
  return(
    <div className='flex gap-8 p-8'>
      <div className='w-40 h-30 p-5 border-4 box-border bg-orange-350'>
        Orange Box
      </div>

      <div className='w-40 h-30 p-5 border-4 box-content bg-purple-350'>
        Purple Box
      </div>  
    </div>
    
  )
}
function Ex() {
  return(
    <div>
      <h3 className='text-3xl font-bold mb-4 text-center'> decoration </h3>
        <p className='underline mb-3 p-3 bg-yellow-300'>텍스트 밑줄</p>
        <p className='overline mb-3 p-3 bg-yellow-300'>텍스트 윗줄</p>
        <p className='line-through mb-3 p-3 bg-yellow-300'>텍스트 취소선</p>
        <a className='no-underline p-3 bg-yellow-300'>기본 deco 삭제</a>
      <h3 className='text-3xl font-bold mb-4 text-center'> decoration style</h3>
        <p className='underline decoration-solid mb-3 p-3 bg-green-200'> 실선 </p>
        <p className='underline decoration-double mb-3 p-3 bg-green-200'> 이중선 </p>
        <p className='underline decoration-dotted mb-3 p-3 bg-green-200'> 점선 </p>
        <p className='underline decoration-dashed mb-3 p-3 bg-green-200'> 파선 </p>
        <p className='underline decoration-wavy mb-3 p-3 bg-green-200'> 물결선 </p>
      <h3 className='text-3xl font-bold mb-4 text-center'> decoration color</h3>
        <p className='underline decoration-red-500 mb-3 p-3 bg-yellow-100'>Red line</p>
        <p className='underline decoration-blue-500 mb-3 p-3 bg-yellow-100'>Blue line</p>
      <h3 className='text-3xl font-bold mb-4 text-center'> decoration size</h3>
        <p className='underline decoration-1 mb-3 p-3 bg-yellow-100'> line 1 </p>
        <p className='underline decoration-2 mb-3 p-3 bg-yellow-100'> line 2 </p>
        <p className='underline decoration-4 mb-3 p-3 bg-yellow-100'> line 4 </p>
    </div>
  )
}

function TextOverflow(){
  return(
    <div className='my-8 p-4 bg-gray-300'>
      <h2 className='text-3xl mb-4 font-bold'> Text Overflow </h2>
      <p className='truncate w-32'>text-weight: thin, extralight, light, normal, medium, semebold, bold</p>
      <div className='w-32 overflow-hidden'>
      <p className='whitespace-nowrap overflow-hidden text-ellipsis'>text-weight: thin, extralight, light, normal, medium, semebold, bold</p>
      <p className='text-clip'>text-weight: thin, extralight, light, normal, medium, semebold, bold</p>
      </div>
    </div>
  )
}

function ShadowBox(){
  return(
    <div className='p-8 my-5 bg-gray-300'>
      <div className='shadow-md bg-white p-4 rounded'> md shdow</div>
      <div className='shadow-lg bg-white p-4 rounded my-4'> md shdow</div>
      <div className='shadow-xl bg-white p-4 rounded shadow-blue-500/50 p-4 my-4'> md shdow</div>
      <button className='bg-blue-500 text-white px-4 py-3 rounded-full 
      transition duration-300 hover:bg-blue-700 active:shadow-xl'>
        Button Hover Effect
      </button>
      <div className='mt-8 bg-green-500 text-white w-16 h-16 px-4 py-4 rounded-full animate-spin'>Spin</div>
      <div className='mt-8 bg-green-500 text-white w-16 h-16 px-4 py-4 rounded-full animate-ping'>ping</div>
      <div className='mt-8 bg-green-500 text-white w-16 h-16 px-4 py-4 rounded-full animate-pulse'>pulse</div>
      <div className='mt-8 bg-green-500 text-white w-16 h-16 px-4 py-4 rounded-full animate-bounce'>bounce</div>
    </div>
  )
}

function App() {
  return (
    <div>
      <div className='p-6'>
        <h1 className='text-3xl font-roboto'>Roboto font</h1>
        <p className='mt-4 font-noto'>Noto Sans KR font.</p>
        <p className='my-4 font-open'>Open Sans font</p>
      </div>
      <Ex />
      <TextOverflow />
      <ShadowBox />
      <FlexRow />
      <FlexCenter />
      <BoxSizing />
    </div>
  );
}

export default App;
