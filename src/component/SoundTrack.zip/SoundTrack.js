import { useEffect, useRef, useState } from "react"
import PlayCircle from "@mui/icons-material/PlayCircle";
import PauseCircle from "@mui/icons-material/PauseCircle";
import SkipPreviousIcon from '@mui/icons-material/SkipPrevious';
import SkipNext from "@mui/icons-material/SkipNext";
import axios from 'axios';

function SoundTrack(){

    const [audioData, setAudioData] = useState([]);
    
    useEffect(()=>{
        const fetchAudio = async () => {
            const audioJson = '/json/audio.json';
            try{
                const response = await axios.get(audioJson);
                setAudioData(response.data);
            } catch(error) {
                alert("에러", error)
            }
        }
        fetchAudio();
    },[])

    const audioRef = useRef(null);
    const [isPlaying, setIsPlaying] = useState(false);
    
    const togglePlay = () =>{
        const audio = audioRef.current;
        if( audio.paused){
            audio.play();
            setIsPlaying(true);
        }else{
            audio.play();
            setIsPlaying(false);
        }
    }


    return(
        <section className="sound-content" style={{position:'relative'}}>
            <div className="title" style={{position:'absolute', top:'100px', left:'50%', transform:'translateX(-50%)'}} >
                <h2>사운드 트랙</h2>
                <p>트랙 제목</p>
            </div>
            
            <div className="track-wrap" style={{position:'absolute', top:'50%', left:'50%', transform:'translate(-50%,-50%)'}}>
                <div className="inner">
                    <div className="play-wrap">
                        <div className="current-track">
                            <div className={`track-list`} style={{height:'300px', width:'300px'}}>
                                {
                                    audioData.map((music, index)=>(
                                        <div key={index} className={`track-${index+1} ${index === 0 ? 'active' : ''}`}>
                                            <img src={music.lp} className={isPlaying ? 'spin' : 'paused'}/>
                                            <audio ref={audioRef} src={music.src}></audio>
                                        </div>
                                    ))
                                }
                            </div>
                            <div className="btn-wrap">
                                    <button><SkipPreviousIcon /></button>
                                    <button onClick={togglePlay}>
                                        {isPlaying ? <PauseCircle style={{ fontSize: '50px'}}/> : <PlayCircle style={{ fontSize: '50px'}}/>}
                                    </button>
                                    <button><SkipNext /></button>
                            </div>
                            <img src="/images/contents/track3.png" alt="place of void" style={{position:'absolute', top:'50%', left:'50%', transform:'translate(-50%,-50%)'}} />
                            
                        </div>
                    </div>
                </div>
            </div>
            <div className="bg-wrap">
                <img src="/images/map/ost_bg.png" alt="ost 배경"/>
            </div>
        </section>
    )
}

export default SoundTrack